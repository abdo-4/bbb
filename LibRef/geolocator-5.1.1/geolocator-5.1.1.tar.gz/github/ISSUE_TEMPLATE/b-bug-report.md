---

name: 🐛 Bug Report
about: Create a report to help us fix bugs and make improvements
---

## 🐛 Bug Report

<!--- Summary description of the bug --->

### Expected behavior

### Reproduction steps

### Configuration

**Version:** 1.x

**Platform:** 
- [ ] :iphone: iOS
- [ ] :robot: Android